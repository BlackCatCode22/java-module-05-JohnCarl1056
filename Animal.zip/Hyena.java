package com.johncarl.zoo;

import java.time.LocalDate;
import java.util.ArrayList;

public class Hyena extends Animal {
    public static void main(String[] args) {

        System.out.println("\n Welcome to my Zoo Keeper Challenge Program\n");

        // Creat a Hyena
        Hyena newHyena = new Hyena();
        Hyena anotherHyena2 = new Hyena();

        //Create a Hyena array list
        ArrayList<Hyena> newHyenaList = new ArrayList<Hyena>();

        newHyenaList.add(newHyena);


        String aUsefulName = "";
        for(int i = 0; i < 4; i++){
            aUsefulName = aUsefulName + i;
            Hyena hyena = new Hyena();
            //add hyena to arraylist
            newHyena.add(hyena);
        }

        //Use the 4 each loop

        for(Hyena aHyena : newHyenaList){
            System.out.println("\n aHyena is " +aHyena);
            System.out.println("\n aHyena name is" + aHyena.getAniName());
        }

    }

    private void add(Hyena hyena) {
    }

    // Static field to track number of Hyenas created
        static int numOfHyenas = 0;

        // Default constructor
    public Hyena() {
            super();
            numOfHyenas++;

            System.out.println("Number of hyenas: " + Hyena.getNumOfHyenas());
            System.out.println("Number of Lions is" + Lion.getNumOfLions());
            System.out.println("Number of animals is" + Animal.getNumOfAnimals());
        }

        // Full constructor using LocalDate for date fields
    public Hyena(String aniSex, LocalDate aniBirthDate, int aniWeight, String aniName,
        int aniID, String aniColor, String aniOrigin, LocalDate aniArrivalDate){
            super(aniSex, aniBirthDate, aniWeight, aniName, aniID, aniColor, aniOrigin, aniArrivalDate);
            numOfHyenas++;
        }

        public Hyena(String aniName) {
        super(aniName);
            numOfHyenas++;
        }

        // Static getter for number of Hyenas
        public static int getNumOfHyenas () {
            return numOfHyenas;
        }





    }

